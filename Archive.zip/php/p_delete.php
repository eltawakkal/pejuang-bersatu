<?php
  require 'koneksi.php';

  $id_member = $_GET['result'];


  $sql = "DELETE FROM tb_anggota WHERE id='$id_member'";

if ($conn->query($sql) === TRUE) {
  header('location: ../pages/list_all_data.php?amanah');
          exit();
  echo "Record deleted successfully";
} else {
  header('location: ../pages/list_all_data.php?amanah');
          exit();
  echo "Error deleting record: " . $conn->error;
}

?>