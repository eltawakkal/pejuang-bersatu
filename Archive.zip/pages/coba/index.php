<?php

	$coba="fadhli al mutawakkil";
	$firstName=explode(' ', $coba);
	echo $firstName;


?>