<?php

	header("location: ../");

?>
